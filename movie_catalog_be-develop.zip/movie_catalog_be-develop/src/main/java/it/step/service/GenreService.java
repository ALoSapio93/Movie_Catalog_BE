package it.step.service;
import it.step.entity.Genre;

import java.util.List;

public interface GenreService {

    public List<Genre> getAllGenres();
}
