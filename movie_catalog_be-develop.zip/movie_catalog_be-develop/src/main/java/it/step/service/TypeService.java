package it.step.service;

import it.step.entity.Type;

import java.util.List;

public interface TypeService {

    public List<Type> getAllTypes();
}
